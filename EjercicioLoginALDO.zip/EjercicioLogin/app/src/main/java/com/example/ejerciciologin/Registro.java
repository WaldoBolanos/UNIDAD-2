package com.example.ejerciciologin;

import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class Registro extends AppCompatActivity {

    EditText txtnombre, txtusuario, txtcontra;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);

        txtnombre=findViewById(R.id.txtnombre);
        txtusuario=findViewById(R.id.txtusuario);
        txtcontra=findViewById(R.id.txtcontra);

    }

    public void altas (View view){

       // AdminSQLiteOpenHelper admin= new AdminSQLiteOpenHelper(this,"administracion",null,1);
       // SQLiteDatabase bd = admin.getWritableDatabase();

    }
}
