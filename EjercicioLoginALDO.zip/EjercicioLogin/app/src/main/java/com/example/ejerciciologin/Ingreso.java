package com.example.ejerciciologin;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Ingreso extends AppCompatActivity {

    private TextView saludoM;
    Bundle datos;
    private Button btncs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ingreso);
        saludoM=findViewById(R.id.name);
        datos=getIntent().getExtras();
        saludoM.setText(datos.getString("nombre"));
        btncs=(Button)findViewById(R.id.btncs);

        btncs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent inicio = new Intent(Ingreso.this, MainActivity.class);
                startActivity(inicio);

            }
        });

    }


    }

