package com.cdp.moverseentreventanas;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class ventana3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ventana3);
    }
    public void venta2(View view){
        Intent nv = new Intent(this, Ventana2.class);
        startActivity(nv);
    }

    public void venta3(View view){
        Intent nv = new Intent(this, ventana3.class);
        startActivity(nv);
    }

    public void venta4(View view){
        Intent nv = new Intent(this, ventana4.class);
        startActivity(nv);
    }

    public void principal(View view){
        Intent nv = new Intent(this, MainActivity.class);
        startActivity(nv);
    }

}